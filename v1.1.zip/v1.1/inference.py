import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import optim
import numpy as np
from model.utils import get_model
from training.dataset.utils import get_dataset
from torch.utils import data
from torch.utils.tensorboard import SummaryWriter

from training.utils import update_ema_variables
from training.losses import DiceLoss
from training.validation import validation
from training.utils import exp_lr_scheduler_with_warmup, log_evaluation_result, get_optimizer
import yaml
import argparse
import time
import math
import os
import sys
import pdb
import warnings

import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.nn.functional as F
from inference.utils import get_inference
from metric.utils import calculate_distance, calculate_dice
import numpy as np
import pdb
import SimpleITK as sitk

warnings.filterwarnings("ignore", category=UserWarning)



def validation(net, data, args):
    net.eval()
    inference = get_inference(args)
    with torch.no_grad():
        images, img_origin, name = data
        inputs = images.float().cuda()
        img_origin = img_origin.cuda()
        pred = inference(net, inputs, args)
        _, label_pred = torch.max(pred, dim=1)
        img_origin[:] = 0
        z1, y1, x1 = 25, 100, 50
        img_origin[:, z1:z1+48, y1:y1+64, x1:x1+80] = label_pred
        outp = sitk.GetImageFromArray(img_origin.data.cpu().numpy().squeeze(0))

        save_path = 'output_1023/acdc_3d_unet_debug/' + name[0]  # acdc_3d_utnetv2, acdc_3d_unet
        sitk.WriteImage(outp, save_path)



def get_parser():
    parser = argparse.ArgumentParser(description='PyTorch Conv-Trans Segmentation')
    parser.add_argument('--inputdata', type=str, default=r'I:\master\Data\RawData\my_train_test_427_1\T1\001_1.nii.gz', help='dataset name')
    parser.add_argument('--dataset', type=str, default='acdc', help='dataset name')
    parser.add_argument('--model', type=str, default='unet', help='model name')
    parser.add_argument('--dimension', type=str, default='2d', help='2d model or 3d model')
    parser.add_argument('--pretrain', action='store_true', help='if use pretrained weight for init')
    parser.add_argument('--batch_size', default=32, type=int, help='batch size') # acdc_3d_utnetv2, acdc_3d_unet
    parser.add_argument('--load', type=str, default='../checkpoint_v1.0/acdc/acdc_3d_unet/0_best.pth', help='load pretrained model')
    parser.add_argument('--cp_path', type=str, default='./checkpoint_v1.0/', help='checkpoint path')
    parser.add_argument('--log_path', type=str, default='./log/', help='log path')
    parser.add_argument('--unique_name', type=str, default='test', help='unique experiment name')
    
    parser.add_argument('--gpu', type=str, default='0')

    args = parser.parse_args()

    config_path = 'config/%s/%s_%s.yaml'%(args.dataset, args.model, args.dimension)
    if not os.path.exists(config_path):
        raise ValueError("The specified configuration doesn't exist: %s"%config_path)

    print('Loading configurations from %s'%config_path)

    with open(config_path, 'r') as f:
        config = yaml.load(f, Loader=yaml.SafeLoader)

    for key, value in config.items():
        setattr(args, key, value)

    return args
    

def init_network(args):
    net = get_model(args, pretrain=args.pretrain)

    if args.load:
        net.load_state_dict(torch.load(args.load)) #, map_location=torch.device('cpu')
        print('Model loaded from {}'.format(args.load))

    if args.ema:
        ema_net = get_model(args, pretrain=args.pretrain)
        for p in ema_net.parameters():
            p.requires_grad_(False)
    else:
        ema_net = None
    return net, ema_net 

def load_data(path_img):
    itk_img = sitk.ReadImage(path_img)
    img = sitk.GetArrayFromImage(itk_img)
    img = img.astype(np.float32)
    tensor_img_ori = img
    img = img[25:73, 100:164, 50:130]
    tensor_img = torch.from_numpy(img).float()
    tensor_img = tensor_img.squeeze(0)
    name = os.path.basename(path_img)
    return tensor_img, tensor_img_ori, name


if __name__ == '__main__':
    
    args = get_parser()
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
    args.log_path = args.log_path + '%s/'%args.dataset
   
    Dice_list = []
    HD_list = []
    ASD_list = []
    i = 0
    net, ema_net = init_network(args)

    net.cuda()
    
    img = load_data(args.inputdata)

    validation(net, img, args)

