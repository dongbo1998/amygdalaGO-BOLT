1. 修改class和class weight.
2. 修改预训练权重和数据集路径。