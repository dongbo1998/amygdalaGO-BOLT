import numpy as np
import os
import cv2 as cv
import SimpleITK as sitk
from medpy import metric

def flip90_left(arr):

    new_arr = np.transpose(arr)

    new_arr = new_arr[::-1]

    return new_arr


models = ['acdc_3d_unet'] # acdc_3d_utnetv2, acdc_3d_unet
for model in models:
    img_path = r'output_418/split/left/' + model + '/'
    gt_path = r'output_418/split/left/gt/'

    gts_data = os.listdir(img_path)
    num = len(gts_data)
    ###########pramenters#############
    hd = []
    AvgHD = []
    HD = []
    dice = []
    JS = []
    VS = []
    hd95 = []
    asd = []
    assd = []
    precision = []
    recall = []
    positive_predictive_value = []
    sensitivity = []
    specificity = []
    true_negative_rate = []
    true_positive_rate = []
    ravd = []
    AvgHD = []
    fp = []
    for k in range(num):
        gt = sitk.ReadImage(gt_path + gts_data[k])
        pred = sitk.ReadImage(img_path + gts_data[k])

        gt = sitk.GetArrayFromImage(gt)
        pred = sitk.GetArrayFromImage(pred)
        gt[gt == 3] = 1
        gt[gt == 4] = 1
        ar,num=np.unique(gt, return_counts=True)
        dice.append( metric.dc(pred, gt))
        JS.append( metric.jc(pred, gt))
        hd95.append( metric.hd95(pred, gt, voxelspacing=1))
        hd.append( metric.hd(pred, gt, voxelspacing=1))
        asd.append( metric.asd(pred, gt, voxelspacing=1))
        assd.append( metric.assd(pred, gt, voxelspacing=1))
        positive_predictive_value.append( metric.positive_predictive_value(pred, gt))
        p = ( metric.precision(pred, gt))
        r = ( metric.recall(pred, gt))
        f = (2 * p*r) / (p + r)
        fp.append(f)
        sensitivity.append(metric.sensitivity(pred, gt))
        specificity.append(metric.specificity(pred, gt))
        ravd.append(metric.ravd(pred, gt))
        precision.append( metric.precision(pred, gt))
        recall.append( metric.recall(pred, gt))
        true_negative_rate.append( metric.true_negative_rate(pred, gt))
        true_positive_rate.append( metric.true_positive_rate(pred, gt))


    import numpy as np
    import pandas as pd

    A = np.array([dice, JS, hd95, hd, asd, assd, fp, precision, recall, sensitivity, specificity, ravd, true_negative_rate, true_positive_rate])
    data = pd.DataFrame(A)

    writer = pd.ExcelWriter('whole_brain_left_' + model + '.xlsx')		# 写入Excel文件
    data.to_excel(writer, sheet_name=model, float_format='%.5f',)		# ‘page_1’是写入excel的sheet名
    writer.save()
    writer.close()

    # print("##" * 10, model, "##" * 10)
    print("Dice", np.mean(dice), np.std(dice))
    # print("JS", np.mean(JS), np.std(JS))
    # print("fp", np.mean(fp), np.std(fp))
    # print("AvgHD", (AvgHD / num) * 1)
    # print("hd95", np.mean(hd95), np.std(hd95))
    # print("hd", np.mean(hd), np.std(hd))
    # print("asd", np.mean(asd), np.std(asd))
    # print("assd", np.mean(assd), np.std(assd))
    # print("precision", np.mean(precision))
    # print("recall", np.mean(recall))
    # print("sensitivity", np.mean(sensitivity))
    # print("specificity", np.mean(specificity))
    # print("true_negative_rate", np.mean(true_negative_rate))
    # print("ravd", np.mean(ravd), np.std(ravd))
    # print("PPV", np.mean(positive_predictive_value),np.std(positive_predictive_value))
    


