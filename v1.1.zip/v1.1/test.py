import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import optim
import numpy as np
from model.utils import get_model
from training.dataset.utils import get_dataset
from torch.utils import data
from torch.utils.tensorboard import SummaryWriter

from training.utils import update_ema_variables
from training.losses import DiceLoss
from training.validation import validation
from training.utils import exp_lr_scheduler_with_warmup, log_evaluation_result, get_optimizer
import yaml
import argparse
import time
import math
import os
import sys
import pdb
import warnings

import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.nn.functional as F
from inference.utils import get_inference
from metric.utils import calculate_distance, calculate_dice
import numpy as np
import pdb
import SimpleITK as sitk

warnings.filterwarnings("ignore", category=UserWarning)



def validation(net, dataloader, args):
    net.eval()

    dice_list = np.zeros(args.classes - 1)  # background is not including in validation
    ASD_list = np.zeros(args.classes - 1)
    HD_list = np.zeros(args.classes - 1)

    inference = get_inference(args)

    counter = 0
    a = []
    with torch.no_grad():
        for i, (images, labels, spacing, img_origin, lab_origin, name) in enumerate(dataloader):
            # spacing here is used for distance metrics calculation

            inputs, labels = images.float().cuda(), labels.long().cuda()
            lab_origin = lab_origin.cuda()
            img_origin = img_origin.cuda()
            if args.dimension == '2d':
                inputs = inputs.permute(1, 0, 2, 3)

            pred = inference(net, inputs, args)

            _, label_pred = torch.max(pred, dim=1)
            # print(label_pred.shape, lab_origin.shape)
            # lab_origin_zero = lab_origin
            # lab_origin_zero[:] = 0
            # lab_origin_zero[:, 30:62, 100:164, 50:130] = label_pred
            # lab_origin = lab_origin_zero * lab_origin
            # print(lab_origin.max())
            lab_origin[:] = 0
            z1, y1, x1 = 25, 100, 50

            lab_origin[:, z1:z1+48, y1:y1+64, x1:x1+80] = label_pred
            outp = sitk.GetImageFromArray(lab_origin.data.cpu().numpy().squeeze(0))
            print(lab_origin.data.cpu().numpy().squeeze(0).shape)


            lab_origin[:] = 0
            
            lab_origin[:, z1:z1+48, y1:y1+64, x1:x1+80] = labels
            ougt = sitk.GetImageFromArray(lab_origin.data.cpu().numpy().squeeze(0))
            print(img_origin.max(), img_origin.min())

            ougt1 = sitk.GetImageFromArray(img_origin.data.cpu().numpy().squeeze(0))
            print(lab_origin.data.cpu().numpy().squeeze(0).shape)

            # print(name)
            save_path = 'output_1023/acdc_3d_unet/' + name[0]  # acdc_3d_utnetv2, acdc_3d_unet
            save_path_gt = 'output_1023/gt/' + name[0] 
            save_path_t1 = 'output_1023/t1/' + name[0] 

            
            sitk.WriteImage(outp, save_path)
            sitk.WriteImage(ougt, save_path_gt)
            sitk.WriteImage(ougt1, save_path_t1)
            

            if args.dimension == '2d':
                labels = labels.squeeze(0)
            else:
                label_pred = label_pred.squeeze(0)
                labels = labels.squeeze(0).squeeze(0)

            # print(i)

            tmp_ASD_list, tmp_HD_list = calculate_distance(label_pred, labels, spacing[0], args.classes)
            ASD_list += np.clip(np.nan_to_num(tmp_ASD_list, nan=500), 0, 500)
            HD_list += np.clip(np.nan_to_num(tmp_HD_list, nan=500), 0, 500)

            dice, _, _ = calculate_dice(label_pred.view(-1, 1), labels.view(-1, 1), args.classes)

            dice_list += dice.cpu().numpy()[1:]
            a.append(dice.cpu().numpy()[1])
            print(a[-1])

            counter += 1
    

    dice_list /= counter
    ASD_list /= counter
    HD_list /= counter

    return dice_list, ASD_list, HD_list



def get_parser():
    parser = argparse.ArgumentParser(description='PyTorch Conv-Trans Segmentation')
    parser.add_argument('--dataset', type=str, default='acdc', help='dataset name')
    parser.add_argument('--model', type=str, default='unet', help='model name')
    parser.add_argument('--dimension', type=str, default='2d', help='2d model or 3d model')
    parser.add_argument('--pretrain', action='store_true', help='if use pretrained weight for init')
    parser.add_argument('--batch_size', default=32, type=int, help='batch size') # acdc_3d_utnetv2, acdc_3d_unet
    parser.add_argument('--load', type=str, default='../checkpoint_v1.0/acdc/acdc_3d_unet/0_best.pth', help='load pretrained model')
    parser.add_argument('--cp_path', type=str, default='./checkpoint_v1.0/', help='checkpoint path')
    parser.add_argument('--log_path', type=str, default='./log/', help='log path')
    parser.add_argument('--unique_name', type=str, default='test', help='unique experiment name')
    
    parser.add_argument('--gpu', type=str, default='0')

    args = parser.parse_args()

    config_path = 'config/%s/%s_%s.yaml'%(args.dataset, args.model, args.dimension)
    if not os.path.exists(config_path):
        raise ValueError("The specified configuration doesn't exist: %s"%config_path)

    print('Loading configurations from %s'%config_path)

    with open(config_path, 'r') as f:
        config = yaml.load(f, Loader=yaml.SafeLoader)

    for key, value in config.items():
        setattr(args, key, value)

    return args
    

def init_network(args):
    net = get_model(args, pretrain=args.pretrain)

    if args.load:
        net.load_state_dict(torch.load(args.load)) #, map_location=torch.device('cpu')
        print('Model loaded from {}'.format(args.load))

    if args.ema:
        ema_net = get_model(args, pretrain=args.pretrain)
        for p in ema_net.parameters():
            p.requires_grad_(False)
    else:
        ema_net = None
    return net, ema_net 


if __name__ == '__main__':
    
    args = get_parser()
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
    args.log_path = args.log_path + '%s/'%args.dataset
   
    Dice_list = []
    HD_list = []
    ASD_list = []
    i = 0
    net, ema_net = init_network(args)

    net.cuda()
    testset = get_dataset(args, mode='test', fold_idx=i)
    testLoader = data.DataLoader(testset, batch_size=1, shuffle=False, num_workers=2)

    dice_list_test, ASD_list_test, HD_list_test = validation(net, testLoader, args)
    
    print(dice_list_test, ASD_list_test, HD_list_test)

